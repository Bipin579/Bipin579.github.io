
import { Box } from '@chakra-ui/react';
import './App.css';
import Hero from './components/Hero';
import Navbar from './components/Navbar';
import Waive from './components/Waive';

function App() {
  return (
    <Box className="App" pb={20} >
      {/* <h1 style={{ fontWeight: "bold", color: "red" }}>Hey there Welcome i am coming soon....</h1> */}
      <Navbar />
      <Hero />
      <Waive />
    </Box>
  );
}

export default App;
