import { Button, Image, Text, Box } from "@chakra-ui/react";

import hero from "../utils/hero.png";

export default function Hero() {
  return (
    <Box m="auto">
      <Box
        display="flex"
        bgColor={"#EBF7FC"}
        flexDirection={["column", "column", "column", "row", "row", "row"]}
        colGap={10}
      >
        <Box
          width={["full", "full", "full", "full", "40%", "40%"]}
          display="flex"
          alignItems={"center"}
        >
          <Box p={10} display="flex" flexDir={"column"} justifyContent="center" m={"auto"}>
            <Text
              lineHeight={1}
              fontWeight={600}
              fontSize={{ base: "4xl", sm: "5xl", lg: "7xl" }}
              color={"#211650"}
              textAlign="center"
            >
              Hii I am Bipin Singh
            </Text>
            <Text fontSize={"xl"} pt={4} color="#E97D20" fontWeight={"500"}>
              I am a Full Stack Javascript Web Developer and loves to build
              websites .
            </Text>
            <Button
              bgColor={"#3944a8"}
              color="white"
              fontWeight={"bold"}
              size="lg"
              variant={"solid"}
              _hover={{ bg: "#0768F8" }}
              my={3}
            >
              Download my Resume
            </Button>
          </Box>
        </Box>
        <Box width={["full", "full", "full", "full", "60%", "60%"]}>
          <Image src={hero} />
        </Box>
      </Box>
    </Box>
  );
}
