import { Box } from "@chakra-ui/react";
import React from "react";
import Wave from "react-wavify";
const Waive = () => {
  return (
    <Box bgColor="#EBF7FC" pt={10}>
      <Wave
        fill="#909EFF"
        
        paused={true}
        options={{
          height: 5,
          amplitude: 40,
          speed: 0.27,
          points: 3,
        }}
      />
    </Box>
  );
};

export default Waive;
